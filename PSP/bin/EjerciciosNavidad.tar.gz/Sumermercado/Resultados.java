package Sumermercado;

public class Resultados {
	
	static int ganancias = 0;
	static int tiempo_espera = 0;
	static int clientes_atendidos = 0;
	
}

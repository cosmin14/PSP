package Parking;

public class Coche extends Thread{
	
	int id;
	Barrera barrera;
	
	public Coche(int id, Barrera barrera) {
		super();
		this.id = id;
		this.barrera = barrera;
	}
	
	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Barrera getBarrera() {
		return barrera;
	}

	public void setBarrera(Barrera barrera) {
		this.barrera = barrera;
	}


	public void run(){
			System.out.println(">   Coche nº "+ id + " y quiero entrar");
			// esperar a que plazas > 0 e inmediatamente plazas--
			// equivale a:
		    try {
				Barrera.barrera1.acquire();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println(">>  Coche nº "+ id + " aparcando...");
			// nos quedamos un ratito aparcados
			try {
			    this.sleep(1000);
			} catch (InterruptedException e) {
			    System.out.print("ERROR");
			}
			// salimos
			System.out.println(">>> Coche nº "+ id + " sale del parking");
			// plazas++;
			// equivale a:
			Barrera.barrera1.release();
	}

}
